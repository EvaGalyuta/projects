﻿using System.Collections.Generic;
/// <summary>
/// Класс склад, хранящий в себе контейнеры.
/// </summary>
class Storage
{
    /// <summary>
    /// Текущая заполненность склада.
    /// </summary>
    private int tmp_capacity = 0;
    /// <summary>
    /// Макисмальная вместимость склада.
    /// </summary>
    private int capacity;
    /// <summary>
    /// Цена, хранения одного контейнера на складе.
    /// </summary>
    private double price;
    /// <summary>
    /// Флаг, указывающий переполненность склада.
    /// </summary>
    public bool is_full = false;
    /// <summary>
    /// Лист контейнеров.
    /// </summary>
    public List<Container> containers;
    /// <summary>
    /// Конструктор склада.
    /// </summary>
    /// <param name="cap">Максимальная вместимость.</param>
    /// <param name="pri">Цена хранения.</param>
    public Storage(int cap, double pri)
    {
        try
        {
            capacity = cap;
            price = pri;
            containers = new List<Container>(capacity);
        }
        catch
        {
            System.Console.WriteLine("error");
        }
        
    }
    /// <summary>
    /// Метод обнуления склада (для доп функционала).
    /// </summary>
    public void NewStore()
    {
        tmp_capacity = 0;
        is_full = false;
        containers.Clear();        
    }
    /// <summary>
    /// Пустой конструктор.
    /// </summary>
    public Storage() { }
    /// <summary>
    /// Свойство доступа к переменной вместимости.
    /// </summary>
    public int Capacity
    {
        set
        {
            capacity = value;
        }
        get
        {
            return capacity;
        }
    }
    /// <summary>
    /// Свойство доступа к переменной текущей заполненности.
    /// </summary>
    public int Tmp_capacity => tmp_capacity;
    /// <summary>
    /// Свойство доступа к цене за хранение на складе.
    /// </summary>
    public double Price
    {
        set
        {
            price = value;
        }
        get
        {
            return price;
        }
    }
    /// <summary>
    /// Метод добавления нового контейнера на склад.
    /// </summary>
    /// <param name="cont">Новый контейнер.</param>
    /// <returns>Измененный склад.</returns>
    public bool AddContainer(Container cont)
    {
        double price_cont = cont.TotalPrice() - cont.TotalPrice() * cont.Damage;
        if (price_cont > price && tmp_capacity < capacity)
        {
            tmp_capacity++;
            containers.Add(cont);
            return true;
        }else if (price_cont > price)
        {
            try
            {
                tmp_capacity = 0;
                is_full = true;
                if (containers != null)
                    containers[tmp_capacity] = cont;
            }
            catch(System.Exception)
            {
                System.Console.WriteLine("error");
            }
            catch 
            {
                System.Console.WriteLine("error");
            }
            
            return true;
        }
        return false;
    }
    /// <summary>
    /// Метод для удаления контейнера.
    /// </summary>
    /// <param name="index">Номер удаляемого контейнера.</param>
    public void DeleteConteiner(int index)
    {
        if (is_full && tmp_capacity == 0)
        {
            tmp_capacity = capacity;
            is_full = false;
        }
        else
        {
            tmp_capacity--;
        }
        containers[index].boxes.Clear();
        containers.RemoveAt(index);
    }
};
