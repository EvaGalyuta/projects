﻿using System;
using System.IO;
using System.Text.RegularExpressions;

/// <summary>
/// Основной класс программы.
/// </summary>
class Program
{
    public static Random rand = new Random();
    /// <summary>
    /// Красивый вывод правил в консоль.
    /// </summary>
    private static void Rules()
    {
        string rules = "Storage of vegetables." + Environment.NewLine + "Hello, you have launched the Storage of vegetables. You can choose some options" + 
            " for your storage. At first, you will need to set parameters of your storage. " +
            Environment.NewLine + "If you want use data from files you should:" + Environment.NewLine +" 1) at file 1storage.txt write one line with" +
            "capacity and price separeted by a space." + Environment.NewLine + " 2) at file 2options.txt write options that you need" +
            "(AddContainer or DeleteContainer index (on the index from 1 to number of containers)) separeted by a line break"
            + Environment.NewLine + " 3) at file 3containersdata.txt write data about containers. Every line is a new container. You should write weight " +
            "and price per kg about each box and separate boxes data with ';'. (example of one container include 3 boxes: \"2 3;3 4;4 5\") " +Environment.NewLine+
            Environment.NewLine +"Press ENTER to continue...";
        int length = rules.Length;
        //позиция, на которой нужно вставить разрыв строки
        int cursor = 0;
        while (length > Console.WindowWidth)
        {
            //Получаем новую строку, которая будет влезать в ширину консоли.
            string newLine = rules.Substring(cursor, Console.WindowWidth - 4);
            int lineLength = newLine.LastIndexOf(' ');
            cursor += lineLength;
            //Вставляем разрыв.
            rules = rules.Insert(cursor, "\n");
            length -= lineLength;
        }
        string[] lines = Regex.Split(rules, "\r\n|\r|\n");
        int left = 0;
        //Определяем отступ сверху для первой строки.
        int top = (Console.WindowHeight / 2) - (lines.Length / 2) - 1;
        //Находим центр консоли сразу, чтобы не грузить приложение лишними вычислениями.
        int center = Console.WindowWidth / 2;
        for (int i = 0; i < lines.Length; i++)
        {
            left = center - (lines[i].Length / 2);
            //Меняем положение курсора.
            Console.SetCursorPosition(left, top);
            //Выводим строку.
            Console.WriteLine(lines[i]);
            top = Console.CursorTop;
        }
    }
    /// <summary>
    /// Вывод текста по центру консоли.
    /// </summary>
    /// <param name="text"></param>
    private static void CentreText(string text)
    {
        //Поиск центра консоли.
        int centerX = (Console.WindowWidth / 2) - (text.Length / 2);
        int centerY = (Console.WindowHeight / 2) - 1;
        Console.SetCursorPosition(centerX, centerY);
        //Вывод текста.
        Console.Write(text);
    }
    /// <summary>
    /// Указатель по строкам.
    /// </summary>
    /// <param name="top"></param>
    /// <param name="y"></param>
    /// <returns></returns>
    private static int Pointer(int top, int y)
    {
        int down = Console.CursorTop;
        Console.CursorTop = top;
        ConsoleKey key;
        while ((key = Console.ReadKey(true).Key) != ConsoleKey.Enter)
        {
            if (key == ConsoleKey.UpArrow)
            {
                if (y > top)
                {
                    y--;
                    Console.CursorTop = y;
                }
            }
            else if (key == ConsoleKey.DownArrow)
            {
                if (y < down - 1)
                {
                    y++;
                    Console.CursorTop = y;
                }
            }
        }
        Console.CursorTop = down;
        return y;
    }
    /// <summary>
    /// Проверка целого числа.
    /// </summary>
    /// <returns></returns>
    private static int TryNumber()
    {
        int test = 0;
        string num;
        int data;
        do
        {
            //Вывод ошибки ввода.
            if (test != 0)
            {
                Console.WriteLine("Wrong input!");
                Console.Write("Enter the number: ");
            }
            test++;
            //Ввод числа и его проверка в уловии цикла.
            num = Console.ReadLine();
        } while (!int.TryParse(num, out data) || data <= 0);
        return data;
    }
    /// <summary>
    /// Проверка дробного числа.
    /// </summary>
    /// <returns></returns>
    private static double TryDouble()
    {
        int test = 0;
        string num;
        double data;
        do
        {
            //Вывод ошибки ввода.
            if (test != 0)
            {
                Console.WriteLine("Wrong input!");
                Console.Write("Enter the number: ");
            }
            test++;
            //Ввод числа и его проверка в уловии цикла.
            num = Console.ReadLine();
        } while (!double.TryParse(num, out data) || data < 0);
        return data;
    }
    /// <summary>
    /// Опции программы.
    /// </summary>
    /// <param name="storage"></param>
    /// <param name="flag"></param>
    private static void Options(Storage storage, bool flag)
    {
        if (!flag)
        {
            Console.WriteLine("Choose option using UP and DOWN keys: " + Environment.NewLine + "1. Add container."
            + Environment.NewLine + "2. Delete container." + Environment.NewLine + "3. Storage info (additional functionality)." +
            Environment.NewLine + "4. Create a new storage (additional functionality)." + Environment.NewLine + "5. Exit program.");
            int y = Pointer(1, 1);
            switch (y)
            {
                case 1: NewContainer(storage); break;
                case 2: DeleteContainer(storage); break;
                case 3: StorageInfo(storage); break;
                case 4: CreateStorage(storage); break;
                case 5: break;
            }
        }
        else
        {
            FileOptions(storage);
        }      
    }
    /// <summary>
    /// Метод удаления контейнера.
    /// </summary>
    /// <param name="storage"></param>
    private static void DeleteContainer(Storage storage)
    {
        Console.Clear();
        if (storage.Tmp_capacity == 0 && !storage.is_full)
        {
            Console.WriteLine("You don't have containers!");
            return;
        }
        Console.WriteLine("Choose container that you want to delete!");
        int count;
        if (storage.is_full)
            count = storage.Capacity;
        else
            count = storage.Tmp_capacity;
        Console.WriteLine($"Your storage (count of containers {storage.Capacity}, price {storage.Price}): ");
        int i = 0;
        foreach (Container ind in storage.containers)
        {
            Console.WriteLine($"{i + 1} container (weight {ind.Weight})");
            ++i;
        }
        int index = Pointer(2, 2);
        storage.DeleteConteiner(index - 2);
        Console.WriteLine("Container was deleted.");
    }
    /// <summary>
    /// Вывод данных о складе.
    /// </summary>
    /// <param name="storage"></param>
    private static void StorageInfo(Storage storage)
    {
        Console.Clear();
        int count;
        if (storage.is_full)
            count = storage.Capacity;
        else
            count = storage.Tmp_capacity;
        Console.WriteLine($"Your storage (count of containers {storage.Capacity}, price {storage.Price}): ");
        int i = 0;
        foreach (Container index in storage.containers)
        {
            Console.WriteLine($"{i + 1} container (weight {index.Weight})");
            for (int j = 0; j < index.boxes.Count; ++j)
            {
                Console.WriteLine($"  {j + 1} box (weight {index.boxes[j].Weight} price {index.boxes[j].Price})");
            }
            ++i;

        }
    }
    /// <summary>
    /// Добавление нового контейнера.
    /// </summary>
    /// <param name="storage"></param>
    private static void NewContainer(Storage storage)
    {
        Console.Clear();
        int mass = (int)rand.Next(50, 1001);
        Container container = new Container(mass);
        Console.Write("Enter the number of boxes: ");
        int num = TryNumber();
        Console.Clear();
        Console.WriteLine("You should enter information about each box :)");
        for(int i = 0; i < num; ++i)
        {
            container.AddBox(NewBox());
        }
        Console.Clear();
        if(storage.AddContainer(container))
            Console.WriteLine("Your container was added!");
        else
            Console.WriteLine("Something went wrong...Your container isn't added...Think about the conditions for adding a container...");
    }
    /// <summary>
    /// Добавление нового ящика.
    /// </summary>
    /// <returns></returns>
    private static Box NewBox()
    {
        Console.Write("Enter the weight of box: ");
        double mass = TryDouble();
        Console.WriteLine();
        Console.Write("Enter the price per kg of this box: ");
        double price = TryDouble();
        Console.Clear();
        Box box = new Box(mass, price);
        return box;
    }
    /// <summary>
    /// Инициализация склада.
    /// </summary>
    /// <param name="flag"></param>
    /// <returns></returns>
    private static Storage NewStorage(bool flag)
    {
        if (flag)
        {
            int capacity;
            double price;
            FileStorage(out capacity, out price);
            if (capacity == -1 || price == -1)
                return new Storage();
            Storage storage = new Storage(capacity, price);
            return storage;
        }
        else
        {
            Console.Write("Enter capacity of your new storage (> 0): ");
            int capacity = TryNumber();
            Console.Clear();
            Console.Write("Enter price of your new storage (>= 0): ");
            double price = TryDouble();
            Console.Clear();
            Storage storage = new Storage(capacity, price);
            return storage;
        }
        
    }
    /// <summary>
    /// Инициализация склада из файла.
    /// </summary>
    /// <param name="capacity"></param>
    /// <param name="price"></param>
    private static void FileStorage(out int capacity, out double price)
    {
        string path = "1storage.txt";
        try
        {
            string data = File.ReadAllText(path);
            string[] numbers = data.Split(" ");
            capacity = int.Parse(numbers[0]);
            price = double.Parse(numbers[1]);
            if (capacity <= 0 || price < 0)
            {
                Console.WriteLine("Incorrect capacity or price of storage...");
                return;
            }
            return;
        }
        catch
        {
            Console.WriteLine("Something went wrong with 1storage.txt...");
        }
        capacity = -1;
        price = -1;
    }
    /// <summary>
    /// Создание нового склада. (ДОП ФУНКЦИОНАЛ)
    /// </summary>
    /// <param name="storage"></param>
    private static void CreateStorage(Storage storage)
    {
        Console.WriteLine("You should enter some data for new storage. Press ENTER to continue...");
        Console.ReadLine();
        Console.Clear();
        Storage store = NewStorage(InputMethod());
        storage.Capacity = store.Capacity;
        storage.Price = store.Price;
        storage.NewStore();
    }
    /// <summary>
    /// Выбор метода ввода данных.
    /// </summary>
    /// <returns></returns>
    private static bool InputMethod()
    {
        Console.WriteLine("Choose input method: ");
        Console.WriteLine("1. Console " + Environment.NewLine + "2. Files");
        int y = Pointer(1, 1);
        switch (y)
        {
            case 1: return false; 
            case 2: return true; 
        }
        return false;
    }
    /// <summary>
    /// Опции из файла.
    /// </summary>
    /// <param name="storage"></param>
    private static void FileOptions(Storage storage)
    {
        try
        {
            int index = 0;
            string[] options = File.ReadAllLines("2options.txt");
            for (int i = 0; i < options.Length; ++i)
            {
                string[] opt = options[i].Split(" ");
                if (opt[0] == "AddContainer")
                {
                    FileContainer(storage, ref index);
                }else if (opt[0] == "DeleteContainer")
                {
                    int ind = int.Parse(opt[1]);
                    FileDelete(storage, ind);
                }
            }
        }
        catch
        {
            Console.WriteLine("Something went wrong with 2options.txt");
        }
        
    }
    /// <summary>
    /// Удаление контейнера из файла.
    /// </summary>
    /// <param name="storage"></param>
    /// <param name="ind"></param>
    private static void FileDelete(Storage storage, int ind)
    {
        if (storage.containers != null && ind <= storage.containers.Count)
        {
            storage.DeleteConteiner(ind - 1);
        }
    }
    /// <summary>
    /// Вывод информации о складе в файл.
    /// </summary>
    /// <param name="storage"></param>
    private static void StorageInfoFile(Storage storage)
    {
        if (storage.containers != null)
        {
            int num = 0;
            for (int j = 0; j < storage.containers.Count; ++j)
                num += storage.containers[j].Count;
            string[] data = new string[1 + storage.containers.Count + num];
            int count;
            if (storage.is_full)
                count = storage.Capacity;
            else
                count = storage.Tmp_capacity;
            data[0] += ($"Your storage (count of containers {storage.Capacity}, price {storage.Price}): ");
            int i = 0;
            foreach (Container index in storage.containers)
            {
                data[i + 1] += ($"{i + 1} container (weight {index.Weight})");
                for (int j = 0; j < index.boxes.Count; ++j)
                {
                    data[i + 1] += ($"  {j + 1} box (weight {index.boxes[j].Weight} price {index.boxes[j].Price})");
                }
                ++i;
            }
            try
            {
                File.AppendAllLines("result.txt", data);
            }
            catch
            {
                Console.WriteLine("Something strange...");
            }
        }
        
    }
    /// <summary>
    /// Ввод информации о контейнере из файла.
    /// </summary>
    /// <param name="storage"></param>
    /// <param name="index"></param>
    private static void FileContainer(Storage storage, ref int index)
    {
        try
        {
            string[] cont = File.ReadAllLines("3containersdata.txt");
            int mass = (int)rand.Next(50, 1001);
            Container container = new Container(mass);
            string[] boxes = cont[index].Split(";");
            for (int i = 0; i < boxes.Length; ++i)
            {
                string[] data = boxes[i].Split(" ");
                double mass_1 = double.Parse(data[0]);
                double money = double.Parse(data[1]);
                Box box = new Box(mass_1, money);
                container.AddBox(box);
            }
            if (!storage.AddContainer(container))
                Console.WriteLine("Something went wrong...Your container isn't added...Think about the conditions for adding a container...");
            index++;
        }
        catch
        {
            Console.WriteLine("Something went wrong with 3containersdata.txt");
        }
    }
    static void Main()
    {
        Rules();
        Console.ReadLine();
        Console.Clear();

        do
        {
            Console.Clear();
            if (InputMethod())
            {
                Storage store = NewStorage(true);
                Console.Clear();
                Options(store, true);
                StorageInfoFile(store);
            }
            else
            {
                Storage store = NewStorage(false);
                Console.Clear();
                Options(store, false);
            }
            Console.WriteLine("Press Esc to exit the program, ");
            Console.WriteLine("press any other key to continue. ");
        } while (Console.ReadKey(true).Key != ConsoleKey.Escape);
        
        
    }
}