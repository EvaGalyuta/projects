﻿using System;
using System.Collections.Generic;
/// <summary>
/// Класс контейнер, состоящий из коробок и имеющий свой вес и урон.
/// </summary>
class Container
{
    /// <summary>
    /// Вес, который лежит в контейнере.
    /// </summary>
    private double weight = 0;
    /// <summary>
    /// Вес, который можно положить в контейнер.
    /// </summary>
    private int max_weight;
    /// <summary>
    /// Урон, нанесенный контейнеру.
    /// </summary>
    private double damage;
    /// <summary>
    /// Количество коробок в контейнере.
    /// </summary>
    private int count;
    /// <summary>
    /// Лист коробок.
    /// </summary>
    public List<Box> boxes;
    /// <summary>
    /// Конструктор для контейнера.
    /// </summary>
    /// <param name="mass"></param>
    public Container(int mass)
    {
        Random rand = new Random();
        max_weight = mass;
        damage = rand.NextDouble() * 0.5;
        boxes = new List<Box>();
    }
    /// <summary>
    /// Свойство для дотупу к весу контейнера.
    /// </summary>
    public double Weight => weight;
    /// <summary>
    /// Свойство для доступа к урону контейнера.
    /// </summary>
    public double Damage => damage;
    /// <summary>
    /// Свойство для доступа к количеству коробок контейнера.
    /// </summary>
    public int Count => count;
    /// <summary>
    /// Метод добавления коробки в контейнер.
    /// </summary>
    /// <param name="a"></param>
    public void AddBox(Box a)
    {
        if (weight + a.Weight <= max_weight)
        {
            boxes.Add(a);
            weight += a.Weight;
            count++;
        }
    }
    /// <summary>
    /// Метод получения общей цены коробок в контейнере.
    /// </summary>
    /// <returns></returns>
    public double TotalPrice()
    {
        double sum = 0;
        for (int i = 0; i < boxes.Count; ++i)
        {
            sum += boxes[i].Price * boxes[i].Weight;
        }
        return sum;
    }
};
