﻿/// <summary>
/// Класс коробка, имеющий вес и цену.
/// </summary>
class Box
{
    /// <summary>
    /// Вес коробки.
    /// </summary>
    private double weight;
    /// <summary>
    /// Цена за кг.
    /// </summary>
    private double price;
    /// <summary>
    /// Конструктор для коробки.
    /// </summary>
    /// <param name="mass">Вес.</param>
    /// <param name="money">Цена за кг.</param>
    public Box(double mass, double money)
    {
        weight = mass;
        price = money;
    }
    /// <summary>
    /// Свойство для веса коробки.
    /// </summary>
    public double Weight
    {
        get
        {
            return weight;
        }
        set
        {
            weight = value;
        }
    }
    /// <summary>
    /// Свойство для цены коробки.
    /// </summary>
    public double Price
    {
        get
        {
            return price;
        }
        set
        {
            price = value;
        }
    }
};
